#include <board.h>
#include "task_msg_bus.h"

#define LOG_TAG              "sample"
#define LOG_LVL              LOG_LVL_DBG
#include <ulog.h>

static void net_reday_callback(task_msg_args_t args)
{
    //这里不要做耗时操作
    LOG_D("[net_reday_callback]:TASK_MSG_NET_REDAY => args->msg_name:%d, args->msg_obj:%s", args->msg_name,
            args->msg_obj);
}

static void os_reday_callback(task_msg_args_t args)
{
    //这里不要做耗时操作
    LOG_D("[os_reday_callback]:TASK_MSG_OS_REDAY => msg_obj is null:%s", args->msg_obj==RT_NULL ? "true" : "false");
}


static void msg_1_thread_entry(void *params)
{
    rt_err_t rst;
    task_msg_args_t args = RT_NULL;
    //创建消息订阅者
    int subscriber_id = task_msg_subscriber_create(TASK_MSG_NET_REDAY);
    if (subscriber_id < 0)
        return;

    while (1)
    {
        rst = task_msg_wait_until(subscriber_id, 1000, &args);
        if (rst == RT_EOK)
        {
            if (args->msg_name == TASK_MSG_NET_REDAY)
            {
                LOG_D("[task111]:TASK_MSG_NET_REDAY => args.msg_name:%d, args.msg_obj:%s", args->msg_name,
                        args->msg_obj);
            }
            rt_thread_mdelay(200);            //模拟耗时操作，在此期间发布的消息不会丢失
            //释放消息
            task_msg_release(args);
        }
        else
        {
            //可以做其它操作，在此期间发布的消息不会丢失
        }
    }
}

static void msg_2_thread_entry(void *params)
{
    rt_err_t rst;
    task_msg_args_t args = RT_NULL;
    //创建消息订阅者
    int subscriber_id = task_msg_subscriber_create(TASK_MSG_NET_REDAY);
    if (subscriber_id < 0)
        return;

    while (1)
    {
        rst = task_msg_wait_until(subscriber_id, 50, &args);
        if (rst == RT_EOK)
        {
            if (args->msg_name == TASK_MSG_NET_REDAY)
            {
                LOG_D("[task222]:TASK_MSG_NET_REDAY => args.msg_name:%d, args.msg_obj:%s", args->msg_name,
                        args->msg_obj);
            }
            rt_thread_mdelay(10);            //模拟耗时操作，在此期间发布的消息不会丢失
            //释放消息
            task_msg_release(args);
        }
        else
        {
            //可以做其它操作，在此期间发布的消息不会丢失
        }
    }
}
static void msg_3_thread_entry(void *params)
{
    rt_err_t rst;
    task_msg_args_t args = RT_NULL;
    //创建消息订阅者
    int subscriber_id = task_msg_subscriber_create(TASK_MSG_NET_REDAY);
    if (subscriber_id < 0)
        return;

    while (1)
    {
        rst = task_msg_wait_until(subscriber_id, 50, &args);
        if (rst == RT_EOK)
        {
            if (args->msg_name == TASK_MSG_NET_REDAY)
            {
                LOG_D("[task333]:TASK_MSG_NET_REDAY => args.msg_name:%d, args.msg_obj:%s", args->msg_name,
                        args->msg_obj);
            }
            rt_thread_mdelay(10);            //模拟耗时操作，在此期间发布的消息不会丢失
            //释放消息
            task_msg_release(args);
        }
        else
        {
            //可以做其它操作，在此期间发布的消息不会丢失
        }
    }
}
static void msg_4_thread_entry(void *params)
{
    rt_err_t rst;
    task_msg_args_t args = RT_NULL;
    //创建消息订阅者
    int subscriber_id = task_msg_subscriber_create(TASK_MSG_NET_REDAY);
    if (subscriber_id < 0)
        return;

    while (1)
    {
        rst = task_msg_wait_until(subscriber_id, 50, &args);
        if (rst == RT_EOK)
        {
            if (args->msg_name == TASK_MSG_NET_REDAY)
            {
                LOG_D("[task444]:TASK_MSG_NET_REDAY => args.msg_name:%d, args.msg_obj:%s", args->msg_name,
                        args->msg_obj);
            }
            rt_thread_mdelay(10);            //模拟耗时操作，在此期间发布的消息不会丢失
            //释放消息
            task_msg_release(args);
        }
        else
        {
            //可以做其它操作，在此期间发布的消息不会丢失
        }
    }
}

static void msg_publish_thread_entry(void *params)
{
    char msg_text[50];
    rt_thread_mdelay(1000);
    while (1)
    {
        //json/text消息
        rt_snprintf(msg_text, 50, "hello");
        task_msg_publish(TASK_MSG_NET_REDAY, msg_text);
        rt_thread_mdelay(3000);
    }
}

static int task_msg_bus_sample(void)
{
    //初始化消息总线(线程栈大小, 优先级, 时间片)
    task_msg_bus_init();
    //订阅消息
    task_msg_subscribe(TASK_MSG_NET_REDAY, net_reday_callback);
    task_msg_subscribe(TASK_MSG_OS_REDAY, os_reday_callback);
    //创建一个等待消息的线程
    rt_thread_t t1 = rt_thread_create("msg_1", msg_1_thread_entry, RT_NULL, 1024, 17, 20);
    rt_thread_startup(t1);
    //创建一个同时等待多个消息的线程
    rt_thread_t t2 = rt_thread_create("msg_2", msg_2_thread_entry, RT_NULL, 1024, 16, 20);
    rt_thread_startup(t2);
    //创建一个等待消息的线程
    rt_thread_t t3 = rt_thread_create("msg_3", msg_3_thread_entry, RT_NULL, 1024, 17, 20);
    rt_thread_startup(t3);
    //创建一个同时等待多个消息的线程
    rt_thread_t t4 = rt_thread_create("msg_4", msg_4_thread_entry, RT_NULL, 1024, 16, 20);
    rt_thread_startup(t4);
    //创建一个发布消息的线程
    rt_thread_t t_publish = rt_thread_create("msg_pub", msg_publish_thread_entry, RT_NULL, 1024, 15, 20);
    rt_thread_startup(t_publish);

    return RT_EOK;
}
INIT_APP_EXPORT(task_msg_bus_sample);
