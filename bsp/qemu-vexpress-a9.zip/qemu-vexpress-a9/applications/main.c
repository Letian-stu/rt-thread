/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020/12/31     Bernard      Add license info
 */

#include <stdint.h>
#include <stdio.h>
#include <rtthread.h>

#include "drv_log.h"

#include "attr.h"
#include "attr_pid_table.h"

#define LOG_TAG     "main"
#define LOG_LVL     LOG_LVL_DBG  
#include <ulog.h>                 

int main(int argc, char *argv[]) 
{
    rt_kprintf("Hello RT-Thread!\n");


	return 0;
}

